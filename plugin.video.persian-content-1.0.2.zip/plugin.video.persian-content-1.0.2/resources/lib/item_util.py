def get_item_name(item_id, item_info={}):
    if 'name' in item_info:
        label = item_info['name']
    else:
        label = item_id

    return label
