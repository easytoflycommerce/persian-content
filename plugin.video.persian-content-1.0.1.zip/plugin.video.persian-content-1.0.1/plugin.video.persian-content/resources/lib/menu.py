import importlib


def get_menu(plugin, menu_id):
    current_menu = importlib.import_module('resources.lib.skeletons.' +
                                           menu_id).menu

    menu = []
    for item_id, item_info in list(current_menu.items()):
        item = (item_id, item_info)
        menu.append(item)

    return menu
