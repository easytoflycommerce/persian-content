menu = {
    'iran_prod': {
        'route': '/resources/lib/websites/iran_proud:get_website_root',
        'name': 'Iran proud',
        'thumb': 'https://i1.sndcdn.com/artworks-000052803915-02aogy-t500x500.jpg',
        'fanart': 'https://i1.sndcdn.com/artworks-000052803915-02aogy-t500x500.jpg'
    }
}