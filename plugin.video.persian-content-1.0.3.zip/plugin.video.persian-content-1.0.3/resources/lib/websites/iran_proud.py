import urlquick
from codequick import Listitem, Resolver, Route
import htmlement
from urllib.parse import urlparse
import json
from resources.lib.analytics import post_analytics
from resources.lib.error_util import post_error
import YDStreamExtractor

URL = 'https://iranproud2.net'
IPTV_URL = 'https://api.gliptv.com/ip.aspx'
YOUTUBE_BASE_URL = 'http://www.youtube.com/watch?v='
PAGE_LIMIT = 50

POPULAR_CATEGORIES = {
    'TV SERIES': {'tag': 'TVSS', 'has_second_level': 'true'},
    'TURKISH SERIES': {'tag': 'TVSS2Turkish', 'has_second_level': 'true'},
    'SERIES ARCHIVE': {'tag': 'TVSS21', 'has_second_level': 'true'},
    'MOVIES': {'tag': 'MovieSS'},
    'MOVIES ARCHIVE': {'tag': 'MovieSS21'},
    'SHOWS': {'tag': 'ShowSS', 'has_second_level': 'true'},
    'MUSIC VIDEOS': {'tag': 'MVSS'},
    'VIDEO CLIPS': {'tag': 'MVSS3'},
    'CARTOON': {'tag': 'TVSS2', 'has_second_level': 'true'},
}


@Route.register
def get_website_root(plugin, item_id):
    response = urlquick.get(URL)
    root = htmlement.fromstring(response.text, "div", attrs={"id": "navBar"})

    # This adds most popular items in home screen
    item = Listitem()
    item.label = "Most popular"
    item.set_callback(get_popular_categories)
    yield item

    for a in root.iterfind(".//a"):
        if a.text == 'HOME':
            continue
        item = Listitem()
        title = a.text
        item.label = title
        url_ref = a.get("href")
        if url_ref.startswith('http'):
            list_url = a.get("href")
        else:
            list_url = URL + a.get("href")

        if a.text == "LIVE TV":
            item.set_callback(get_channel_categories, title, list_url)
        else:
            item.set_callback(get_category_menus, title, list_url)
        yield item


@Route.register
def get_popular_categories(plugin):
    response = urlquick.get(URL)
    root = htmlement.fromstring(response.text)
    post_analytics("Popular categories", "")

    # Banner
    item = Listitem()
    item.label = "Banner"
    item.set_callback(get_banner)
    yield item

    categories = root.findall(".//div[@id=\"divTitrSS2\"]")
    if len(categories) > 0:
        for category in categories:
            item = Listitem()
            title = category.text
            if 'LIVE TV' in title.upper():
                continue
            item.label = title

            item.set_callback(get_items_in_popular_category, title)
            yield item


@Route.register
def get_banner(plugin):
    response = urlquick.get(URL)
    root = htmlement.fromstring(response.text, "div", attrs={"id": "BigSSP"})

    banners = root.findall(".//a")
    if len(banners) > 0:
        for banner in banners:
            item = Listitem()
            banner_url_string = banner.get("href")
            banner_url = urlparse(banner_url_string)
            banner_name = banner_url.path.rsplit("/", 1)[-1]
            item.label = banner_name

            thumb = banner.find(".//img").get("src")
            item.art["thumb"] = thumb
            item.art["fanart"] = thumb

            url_tag = banner.get("href")
            if 'movies' in url_tag:
                item.set_callback(get_url, banner_name, url_tag)
            else:
                item.set_callback(get_second_level_list, banner_name, url_tag)
            yield item


@Route.register
def get_items_in_popular_category(plugin, title):
    post_analytics(title, "")

    if title in POPULAR_CATEGORIES:
        response = urlquick.get(URL)
        popular_category = POPULAR_CATEGORIES.get(title)
        root = htmlement.fromstring(response.text, "div", attrs={"id": popular_category['tag']})
        categories = root.findall(".//a")
        tmp_image = ''
        if len(categories) > 0:
            for category in categories:
                if category.get("href") == "#":
                    tmp_image = category.find(".//img").get("src")
                    continue

                item = Listitem()
                url_ref = category.get("href")
                final_url = url_ref if url_ref.startswith('http') else URL + url_ref

                banner_name_tag = category.find(".//div[@class=\"SSh1\"]")
                if banner_name_tag is not None:
                    banner_name = banner_name_tag.text
                else:
                    banner_url = urlparse(final_url)
                    banner_name = banner_url.path.rsplit("/", 1)[-1]

                item.label = banner_name
                thumb = tmp_image if tmp_image != '' else category.find(".//img").get("src")
                item.art["thumb"] = thumb
                item.art["fanart"] = thumb

                if 'has_second_level' not in popular_category:
                    item.set_callback(get_url, banner_name, final_url)
                else:
                    item.set_callback(get_second_level_list, banner_name, final_url)

                tmp_image = ''
                yield item
    else:
        post_error(0, title + "couldn't find", "")


@Route.register
def get_category_menus(plugin, title, url):
    response = urlquick.get(url)
    root = htmlement.fromstring(response.text)

    post_analytics(title, url)

    categories = root.findall(".//div[@id=\"divTextSS1b\"]")
    if len(categories) > 0:
        for r in categories:
            item = Listitem()
            title_tag = r.find(".//div[@id=\"divTitrSS2\"]")
            if title_tag is None:
                continue
            item.label = title_tag.text
            url_tag = r.find(".//a")
            item.set_callback(get_list, title_tag.text, url_tag.get("href"))
            yield item


@Route.register
def get_channel_categories(plugin, title, url):
    response = urlquick.get(url)
    root = htmlement.fromstring(response.text)

    post_analytics(title, url)

    categories = root.findall(".//div[@id=\"divTitrGrid2\"]")
    for category in categories:
        item = Listitem()

        category_name = category.text
        item.label = category_name
        item.set_callback(get_channels, url, category_name)
        yield item


@Route.register
def get_channels(plugin, url, category_name):
    response = urlquick.get(url)
    root = htmlement.fromstring(response.text)

    post_analytics(category_name, url)

    categories = root.findall(".//div[@id=\"divTitrGrid2\"]")
    channels = root.findall(".//ul[@id=\"gridMason\"]")
    for index, category in enumerate(categories):
        if category.text == category_name:
            iptv_response = urlquick.get(IPTV_URL)
            json_parser = json.loads(iptv_response.text)
            ip = json_parser['clienIP']

            channels = channels[index].findall(".//li")
            for channel in channels:
                item = Listitem()

                channel_url_string = channel.find(".//a").get("href")
                channel_url = urlparse(channel_url_string)
                channel_name = channel_url.path.rsplit("/", 1)[-1]
                item.label = channel_name

                final_url = URL + channel_url_string + '/' + ip

                thumb = channel.find(".//img").get("src")
                item.art["thumb"] = thumb
                item.art["fanart"] = thumb

                item.set_callback(get_url, channel_name, final_url)
                yield item


@Route.register
def get_list(plugin, title, url, start=0):
    headers = {'Content-type': 'application/x-www-form-urlencoded'}
    data = "displayoption=Recently Added&limitrecords=" + str(PAGE_LIMIT) + "&skiprecords=" + str(start)
    response = urlquick.post(url=url, data=data, headers=headers)
    root = htmlement.fromstring(response.text)

    post_analytics(title, url)

    categories = root.findall(".//li")
    if len(categories) == PAGE_LIMIT:
        yield Listitem.next_page(
            title="next page",
            url=url,
            start=start + 1)
    for r in categories:
        item = Listitem()

        if r.find(".//div[@class=\"SSh1\"]") is not None:
            title = r.find(".//div[@class=\"SSh1\"]").text
        elif r.find(".//div[@class=\"SSh2\"]") is not None:
            title = r.find(".//div[@class=\"SSh2\"]").text
        elif r.find(".//div[@class=\"SSh3\"]") is not None:
            title = r.find(".//div[@class=\"SSh3\"]").text
        elif r.find(".//div[@class=\"SSh1M\"]") is not None:
            title = r.find(".//div[@class=\"SSh1M\"]").text
        elif r.find(".//div[@id=\"divEpiNo1\"]") is not None:
            title = "Episode: " + r.find(".//div[@id=\"divEpiNo1\"]").text
        else:
            continue

        item.label = title

        list_url = r.find(".//a").get("href")
        if list_url.startswith("http"):
            final_url = list_url
            item.set_callback(get_second_level_list, title, final_url)
        else:
            final_url = URL + list_url
            item.set_callback(get_url, title, final_url)

        thumb = r.find(".//img").get("src")
        item.art["thumb"] = thumb
        item.art["fanart"] = thumb
        yield item
    return


@Route.register
def get_second_level_list(plugin, title, url):
    response = urlquick.get(url)
    root = htmlement.fromstring(response.text)

    post_analytics(title, url)

    seasons = root.find(".//div[@class=\"titrSeason\"]")
    if seasons is not None:
        for season in seasons.findall(".//span"):
            item = Listitem()

            season_tag = season.find(".//a")

            if season_tag.get("seriesid") is not None:
                content_id = season_tag.get("seriesid")
            elif season_tag.get("showsid") is not None:
                content_id = season_tag.get("showsid")

            page_name = season_tag.get("pagename")
            season_number = season_tag.get("seasonno")

            title = "Season: " + season_number
            item.label = title

            final_url = URL + "/views/season/" + season_number + "/" + page_name + "/" + content_id

            item.set_callback(get_list, title, final_url)
            yield item


@Resolver.register
def get_url(plugin, title, url):
    response = urlquick.get(url)
    root = htmlement.fromstring(response.text)

    post_analytics(title, url)

    video_container = root.find(".//source[@id='videoTagSrc']")
    if video_container is not None:
        video_url = video_container.get("src")
        return video_url

    video_container = root.find(".//source")
    if video_container is not None:
        video_url = video_container.get("src")
        return video_url

    if 'var youtube_video=' in response.text:
        tmp_url = urlparse(url)
        youtube_id = tmp_url.path.rsplit("/", 1)[-1]
        youtube_url = YOUTUBE_BASE_URL + youtube_id
        vid = YDStreamExtractor.getVideoInfo(youtube_url, quality=2)
        return vid.streamURL()

