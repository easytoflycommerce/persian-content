import re


class M3uParser:

    def parse(self, m3u_text):
        return self.__handle_lines(m3u_text)

    def __handle_lines(self, m3u_text):
        channels = []
        lines = m3u_text.split('#EXTINF:')
        if len(lines) == 1:
            return channels

        for line in lines:
            result = re.search("tvg-name=\"(.*?)\"", line)
            if result:
                name = result.group(1)
                result = re.search("tvg-logo=\"(.*?)\"", line)
                logo = result.group(1)
                url = self.__get_url(line)
                channel = (name, logo, url)
                channels.append(channel)
        return channels

    def __get_url(self, line):
        lines = line.split('\n')
        return lines[len(lines) - 2]
