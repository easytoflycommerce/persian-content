import urlquick
from codequick import Listitem, Route
from resources.lib.m3u_parser import M3uParser
from codequick import Resolver
from resources.lib.analytics import post_analytics

URL = 'http://iptv.jaze.xyz/ir.m3u'


@Route.register
def get_channel_root(plugin, item_id):
    response = urlquick.get(URL)
    channels = M3uParser().parse(response.text)

    post_analytics("Jaze_m3u", "")

    for (name, logo, url) in channels:
        item = Listitem()

        item.label = name
        item.art["thumb"] = logo
        item.art["fanart"] = logo

        item.set_callback(get_url, name, url)
        yield item


@Resolver.register
def get_url(plugin, title, url):
    post_analytics(title, url)
    return url
