from codequick import Route, Resolver, Listitem
import xbmc
import xbmcgui

from resources.lib.menu import get_menu
from resources.lib.item_util import get_item_name


# import web_pdb; web_pdb.set_trace()

@Route.register
def root(plugin):
    """Build root menu of the addon (Live TV, Website, ...)
    Args:
        plugin (codequick.script.Script)
    Returns:
        Iterator[codequick.listing.Listitem]: Kodi root menu
    """

    # First menu to build is the root menu
    # (see 'menu' dictionnary in root.py)
    return populate_menu(plugin, 'root')


@Route.register
def populate_menu(plugin, item_id=None):
    """Build 'item_id' menu of the addon
    Args:
        plugin (codequick.script.Script)
        item_id (str): Menu to build (e.g. root)
    Returns:
        Iterator[codequick.listing.Listitem]: Kodi 'item_id' menu
    """

    if item_id is None:
        xbmc.executebuiltin("Action(Back,%s)" % xbmcgui.getCurrentWindowId())
        yield False

    else:
        menu_id = item_id

        # If 'menu_id' menu contains only one item, directly open this item
        plugin.redirect_single_item = True

        # Get menu
        menu = get_menu(plugin, menu_id)

        if not menu:
            # If the selected menu is empty just reload the current menu
            yield False

        for (item_id, item_info) in menu:

            item = Listitem()

            # Set item name
            item.label = get_item_name(item_id, item_info)

            # Set item art
            if 'thumb' in item_info:
                item.art["thumb"] = item_info['thumb']

            if 'fanart' in item_info:
                item.art["fanart"] = item_info['fanart']

            item.params['item_id'] = item_id

            # Set callback function for this item
            if 'route' in item_info:
                item.set_callback((Route.ref(item_info['route'])))
            elif 'resolver' in item_info:
                item.set_callback((Resolver.ref(item_info['resolver'])))
            else:
                # This case should not happen
                # Ignore this item to prevent any error for this menu
                continue

            yield item
