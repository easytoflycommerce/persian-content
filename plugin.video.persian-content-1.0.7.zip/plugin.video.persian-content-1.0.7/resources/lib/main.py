import urlquick
from codequick import Route, Resolver, Listitem
import json

BASE_URL = 'http://192.168.0.8:8080/api'

@Route.register
def root(plugin):
    final_url = BASE_URL + "/main/menus"

    return populate_menu(plugin, final_url)


@Route.register
def populate_menu(plugin, top_url):
    """Build 'top_url' menu of the addon
    Args:
        plugin (codequick.script.Script)
        top_url (str): Menu to build (e.g. root)
    Returns:
        Iterator[codequick.listing.Listitem]: Kodi 'item_id' menu
    """

    response = urlquick.get(top_url)
    data = json.loads(response.text)
    menus = data["menus"]

    for menu in menus:
        name = menu["name"]
        thumb_url = menu["thumbUrl"]
        url = menu["url"]

        item = Listitem()

        # Set item name
        item.label = name

        # Set item art
        item.art["thumb"] = thumb_url
        item.art["fanart"] = thumb_url

        if url.startswith("http"):
            item.set_callback(url)
        else:
            item.set_callback(populate_menu, BASE_URL + url)

        yield item


