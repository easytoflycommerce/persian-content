import urlquick
import xbmcgui
from codequick import Script
from resources.lib.analytics import post_error


def error_handler(exception):
    if isinstance(exception, urlquick.HTTPError):
        code = exception.code
        msg = exception.msg
        url = exception.filename
        Script.log('urlquick.get() failed with HTTPError code {} with message "{}"'.format(code, msg, lvl=Script.ERROR))

        post_error(code=str(code), message=msg, url=url)

        # Build dialog message
        dialog_message = msg

        http_code_msg = {
            500: 30891,
            401: 30892,
            403: 30893,
            402: 30894,
            404: 30895
        }

        if code in http_code_msg:
            dialog_message = Script.localize(http_code_msg[code])

        # Build dialog title
        dialog_title = Script.localize(30890) + ' ' + str(code)

        # Show xbmc dialog
        xbmcgui.Dialog().ok(dialog_title, dialog_message)
