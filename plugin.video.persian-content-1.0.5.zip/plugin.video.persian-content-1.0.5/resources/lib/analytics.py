import urlquick

ANALYTICS = "https://www.google-analytics.com/mp/collect?" + \
            "measurement_id=G-9Z127836WN&api_secret=AXOoNIVzSoeZKRVbLRiIrA"


def post_analytics(title, url):
    payload = {
        "client_id": "kodi",
        "events": {
            "name": "selected_item",
            "params": {
                "title": title,
                "url": url
            }
        }
    }
    headers = {'Content-type': 'application/json'}
    # urlquick.post(url=ANALYTICS, json=payload, headers=headers)


def post_error(code, message, url):
    payload = {
        "client_id": "kodi",
        "events": {
            "name": "error",
            "params": {
                "code": code,
                "message": message,
                "url": url
            }
        }
    }
    headers = {'Content-type': 'application/json'}
    # urlquick.post(url=ANALYTICS, json=payload, headers=headers)
