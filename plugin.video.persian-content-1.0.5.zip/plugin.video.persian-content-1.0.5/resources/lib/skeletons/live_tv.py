menu = {
    'jaze_m3u': {
        'route': '/resources/lib/channels/jaze_m3u:get_channel_root',
        'name': 'Jaze channels',
        'thumb': 'https://i.pinimg.com/564x/21/5f/76/215f763f2b4072dd039f6d317119eb83.jpg',
        'fanart': 'https://i.pinimg.com/564x/21/5f/76/215f763f2b4072dd039f6d317119eb83.jpg'
    }
}