menu = {
    'live_tv': {
        'name': 'Live tv',
        'thumb': 'https://i.pinimg.com/564x/21/5f/76/215f763f2b4072dd039f6d317119eb83.jpg',
        'route': '/resources/lib/main:populate_menu',
    },
    'website': {
        'name': 'Website',
        'thumb': 'https://i1.sndcdn.com/artworks-000052803915-02aogy-t500x500.jpg',
        'route': '/resources/lib/main:populate_menu',
    }
}