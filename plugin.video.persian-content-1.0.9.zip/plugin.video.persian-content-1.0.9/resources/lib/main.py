import urlquick
from codequick import Route, Resolver, Listitem
import json

BASE_URL = 'http://192.168.0.12:8085/api'


@Route.register
def root(plugin):
    final_url = BASE_URL + "/main/menus"
    return populate_menus(plugin, final_url)


@Route.register
def populate_menus(plugin, top_url):
    """Build 'top_url' menu of the addon
    Args:
        plugin (codequick.script.Script)
        top_url (str): Menu to build (e.g. root)
    Returns:
        Iterator[codequick.listing.Listitem]: Kodi 'item_id' menu
    """

    response = urlquick.get(top_url)
    data = json.loads(response.text)
    menus = data["menus"]

    for menu in menus:
        menu_id = menu["id"]
        name = menu["name"]
        thumb_url = menu["thumbUrl"]
        url = menu["url"]

        if menu_id == "SEARCH":
            full_url = BASE_URL + url
            yield Listitem.search(search_content, full_url=full_url)
            continue
        else:
            item = Listitem()

        # Set item name
        item.label = name

        # Set item art
        item.art["thumb"] = thumb_url
        item.art["fanart"] = thumb_url

        if menu_id == "play_id":
            item.set_callback(play_video, BASE_URL + url)
        else:
            item.set_callback(populate_menus, BASE_URL + url)

        yield item


@Route.register
def search_content(plugin, search_query, full_url):
    url = full_url + search_query
    return populate_menus(plugin, url)


@Resolver.register
def play_video(plugin, url):
    response = urlquick.get(url)
    data = json.loads(response.text)
    menus = data["menus"]

    # Get the base URL from the menus
    video_url = menus[0]["url"]

    # Define the custom headers to append to the URL
    headers = (
        "User-Agent=Mozilla/5.0%20(X11;%20Linux%20x86_64)%20AppleWebKit/537.36%20(KHTML,%20like%20Gecko)"
    )

    # Combine the video URL with the custom headers in the Kodi-compatible format
    kodi_compatible_url = f"{video_url}|{headers}"

    return kodi_compatible_url



